﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class adminfooddelivery : Form
    {
        private readonly string connectionString =
            "data source=HPVICTUS15\\SQLEXPRESS; database=ERideDB; integrated security=SSPI";

        private readonly string phone_number;

        public adminfooddelivery(string phone_number)
        {
            InitializeComponent();
            this.phone_number = phone_number;
        }
        public adminfooddelivery()
        {
            InitializeComponent();
        }

        private void btnManageRestaurants_Click(object sender, EventArgs e)
        {
            adminRestaurants ares = new adminRestaurants(phone_number);
            ares.Show();
            this.Hide();
        }

        private void btnManageFoodItems_Click(object sender, EventArgs e)
        {
            adminFoodItems afi = new adminFoodItems(phone_number);
            afi.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            admindashboard ad = new admindashboard(phone_number);   
            ad.Show();
            this.Close();
        }

        private void btnManageOrders_Click(object sender, EventArgs e)
        {
            adminOrders ao = new adminOrders(phone_number);    
            ao.Show();
            this.Hide();
        }
    }
}
