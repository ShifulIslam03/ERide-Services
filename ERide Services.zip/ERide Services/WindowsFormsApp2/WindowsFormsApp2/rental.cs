﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class rental : Form
    {
        string connectionString =
            "data source=HPVICTUS15\\SQLEXPRESS; database=ERideDB; integrated security=SSPI";

        private int currentTransferId = -1;
        private const decimal RATE_PER_MIN = 2m;

        private string phone_number;

        public rental(string phone_number)
        {
            InitializeComponent();
            this.phone_number = phone_number;
        }

        public rental()
        {
            InitializeComponent();
        }

        private void rental_Load(object sender, EventArgs e)
        {
            LoadStationsToCombo();
            LoadStationGrid();

            btnEndRide.Enabled = false;
            btnStartRide.Enabled = true;
        }

        private void LoadStationsToCombo()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            using (SqlDataAdapter da = new SqlDataAdapter(
                "SELECT StationId, Station_Name FROM dbo.Station ORDER BY Station_Name", con))
            {
                DataTable dt = new DataTable();
                da.Fill(dt);

                startstation.DisplayMember = "Station_Name";
                startstation.ValueMember = "StationId";
                startstation.DataSource = dt.Copy();

                endstation.DisplayMember = "Station_Name";
                endstation.ValueMember = "StationId";
                endstation.DataSource = dt;
            }
        }
        private void btnBack_Click(object sender, EventArgs e)
        {
            
            services f = new services(phone_number);
            f.Show();
            this.Hide();
        }

        private void LoadStationGrid()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            using (SqlDataAdapter da = new SqlDataAdapter(
                "SELECT Station_Name, Block, Road, Available FROM dbo.Station", con))
            {
                DataTable dt = new DataTable();
                da.Fill(dt);
                gridHistory.DataSource = dt;
            }
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
          
        }

        private void startstation_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void endstation_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }
      

        private void btnStartRide_Click(object sender, EventArgs e)
        {
            if (startstation.SelectedValue == null || endstation.SelectedValue == null)
            {
                MessageBox.Show("Please select both Start and End stations.");
                return;
            }

            int startId = Convert.ToInt32(startstation.SelectedValue);
            int endId = Convert.ToInt32(endstation.SelectedValue);

            if (startId == endId)
            {
                MessageBox.Show("Start and End station cannot be same.");
                return;
            }

            int qty = (int)numCycle.Value;
            if (qty <= 0)
            {
                MessageBox.Show("Cycle quantity must be at least 1.");
                return;
            }

            DateTime startTime = DateTime.Now;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                SqlTransaction tx = con.BeginTransaction();

                try
                {
                    int startAvailable;

                   
                    using (SqlCommand cmd = new SqlCommand(
                        "SELECT Available FROM dbo.Station WHERE StationId=@id", con, tx))
                    {
                        cmd.Parameters.AddWithValue("@id", startId);
                        object val = cmd.ExecuteScalar();
                        startAvailable = (val == null || val == DBNull.Value) ? 0 : Convert.ToInt32(val);
                    }

                    if (startAvailable < qty)
                    {
                        tx.Rollback();
                        MessageBox.Show("Not enough cycles available at Start Station.");
                        return;
                    }

                    using (SqlCommand cmd = new SqlCommand(
                        "UPDATE dbo.Station SET Available = Available - @qty WHERE StationId=@id", con, tx))
                    {
                        cmd.Parameters.AddWithValue("@qty", qty);
                        cmd.Parameters.AddWithValue("@id", startId);
                        cmd.ExecuteNonQuery();
                    }

                    using (SqlCommand cmd = new SqlCommand(@" INSERT INTO dbo.TransferHistory (Phone_Number, StartStationId, EndStationId, CycleCount, TransferTime, StartTime, RatePerMinute) OUTPUT INSERTED.TransferId VALUES (@phone, @start, @end, @qty, GETDATE(), @startTime, @rate);", con, tx))
                    {
                        cmd.Parameters.AddWithValue("@phone", (object)phone_number ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@start", startId);
                        cmd.Parameters.AddWithValue("@end", endId);
                        cmd.Parameters.AddWithValue("@qty", qty);
                        cmd.Parameters.AddWithValue("@startTime", startTime);
                        cmd.Parameters.AddWithValue("@rate", RATE_PER_MIN);

                        currentTransferId = Convert.ToInt32(cmd.ExecuteScalar());
                    }

                    tx.Commit();

                    btnStartRide.Enabled = false;
                    btnEndRide.Enabled = true;

                    MessageBox.Show("Ride started!");
                    LoadStationGrid();
                }
                catch (Exception ex)
                {
                    tx.Rollback();
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void btnEndRide_Click(object sender, EventArgs e)
        {
            if (currentTransferId <= 0)
            {
                MessageBox.Show("No active ride found. Please press Start first.");
                return;
            }

            DateTime endTime = DateTime.Now;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                SqlTransaction tx = con.BeginTransaction();

                try
                {
                    DateTime startTime;
                    decimal ratePerMin;
                    int qty;
                    int endId;

                    using (SqlCommand cmd = new SqlCommand(@"SELECT StartTime, RatePerMinute, CycleCount, EndStationId FROM dbo.TransferHistory WHERE TransferId=@tid;", con, tx))
                    {
                        cmd.Parameters.AddWithValue("@tid", currentTransferId);

                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            if (!dr.Read() || dr["StartTime"] == DBNull.Value)
                            {
                                MessageBox.Show("StartTime missing. Cannot end ride.");
                                dr.Close();
                                tx.Rollback();
                                return;
                            }

                            startTime = Convert.ToDateTime(dr["StartTime"]);
                            ratePerMin = (dr["RatePerMinute"] == DBNull.Value)
                                ? RATE_PER_MIN
                                : Convert.ToDecimal(dr["RatePerMinute"]);

                            qty = Convert.ToInt32(dr["CycleCount"]);
                            endId = Convert.ToInt32(dr["EndStationId"]);
                        }
                    }

                    int durationMinutes = (int)Math.Ceiling((endTime - startTime).TotalMinutes);
                    if (durationMinutes < 1) durationMinutes = 1;

                    decimal totalAmount = durationMinutes * ratePerMin * qty;

                    
                    using (SqlCommand cmd = new SqlCommand(
                        "UPDATE dbo.Station SET Available = Available + @qty WHERE StationId=@id", con, tx))
                    {
                        cmd.Parameters.AddWithValue("@qty", qty);
                        cmd.Parameters.AddWithValue("@id", endId);
                        cmd.ExecuteNonQuery();
                    }

                    using (SqlCommand cmd = new SqlCommand(@" UPDATE dbo.TransferHistory SET EndTime=@endTime, DurationMinutes=@dur, TotalAmount=@total WHERE TransferId=@tid;", con, tx))
                    {
                        cmd.Parameters.AddWithValue("@endTime", endTime);
                        cmd.Parameters.AddWithValue("@dur", durationMinutes);
                        cmd.Parameters.AddWithValue("@total", totalAmount);
                        cmd.Parameters.AddWithValue("@tid", currentTransferId);
                        cmd.ExecuteNonQuery();
                    }

                    tx.Commit();

                    MessageBox.Show($"Ride ended!\nDuration: {durationMinutes} min\nTotal: {totalAmount} ৳");

                    currentTransferId = -1;
                    btnStartRide.Enabled = true;
                    btnEndRide.Enabled = false;

                    LoadStationGrid();
                }
                catch (Exception ex)
                {
                    tx.Rollback();
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }
    }
}
