﻿namespace WindowsFormsApp2
{
    partial class register
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.UserName = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Password = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.Date_of_Birth = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.Age = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.Gender = new System.Windows.Forms.Label();
            this.Area = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.Block = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.Road_No = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.Phone_Number = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.Create_Account = new System.Windows.Forms.Button();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.btlogin = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Gold;
            this.label1.Font = new System.Drawing.Font("Calibri", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(571, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(207, 37);
            this.label1.TabIndex = 1;
            this.label1.Text = "Create Account";
            // 
            // UserName
            // 
            this.UserName.AutoSize = true;
            this.UserName.BackColor = System.Drawing.Color.Gold;
            this.UserName.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserName.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.UserName.Location = new System.Drawing.Point(483, 168);
            this.UserName.Name = "UserName";
            this.UserName.Size = new System.Drawing.Size(78, 19);
            this.UserName.TabIndex = 3;
            this.UserName.Text = "Username";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.textBox1.Location = new System.Drawing.Point(629, 163);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(119, 26);
            this.textBox1.TabIndex = 4;
            // 
            // Password
            // 
            this.Password.AutoSize = true;
            this.Password.BackColor = System.Drawing.Color.Gold;
            this.Password.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Password.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Password.Location = new System.Drawing.Point(483, 263);
            this.Password.Name = "Password";
            this.Password.Size = new System.Drawing.Size(74, 19);
            this.Password.TabIndex = 5;
            this.Password.Text = "Password";
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.textBox2.Location = new System.Drawing.Point(629, 263);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(119, 26);
            this.textBox2.TabIndex = 6;
            // 
            // Date_of_Birth
            // 
            this.Date_of_Birth.AutoSize = true;
            this.Date_of_Birth.BackColor = System.Drawing.Color.Gold;
            this.Date_of_Birth.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Date_of_Birth.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Date_of_Birth.Location = new System.Drawing.Point(483, 420);
            this.Date_of_Birth.Name = "Date_of_Birth";
            this.Date_of_Birth.Size = new System.Drawing.Size(99, 19);
            this.Date_of_Birth.TabIndex = 7;
            this.Date_of_Birth.Text = "Date of Birth";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CalendarForeColor = System.Drawing.Color.LightGoldenrodYellow;
            this.dateTimePicker1.CalendarMonthBackground = System.Drawing.Color.LightGoldenrodYellow;
            this.dateTimePicker1.CalendarTrailingForeColor = System.Drawing.Color.LightGoldenrodYellow;
            this.dateTimePicker1.Location = new System.Drawing.Point(629, 413);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(235, 26);
            this.dateTimePicker1.TabIndex = 8;
            // 
            // Age
            // 
            this.Age.AutoSize = true;
            this.Age.BackColor = System.Drawing.Color.Gold;
            this.Age.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Age.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Age.Location = new System.Drawing.Point(483, 314);
            this.Age.Name = "Age";
            this.Age.Size = new System.Drawing.Size(36, 19);
            this.Age.TabIndex = 9;
            this.Age.Text = "Age";
            this.Age.Click += new System.EventHandler(this.Age_Click);
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.textBox3.Location = new System.Drawing.Point(629, 313);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(119, 26);
            this.textBox3.TabIndex = 10;
            // 
            // Gender
            // 
            this.Gender.AutoSize = true;
            this.Gender.BackColor = System.Drawing.Color.Gold;
            this.Gender.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Gender.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Gender.Location = new System.Drawing.Point(483, 369);
            this.Gender.Name = "Gender";
            this.Gender.Size = new System.Drawing.Size(59, 19);
            this.Gender.TabIndex = 11;
            this.Gender.Text = "Gender";
            // 
            // Area
            // 
            this.Area.AutoSize = true;
            this.Area.BackColor = System.Drawing.Color.Gold;
            this.Area.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Area.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Area.Location = new System.Drawing.Point(483, 473);
            this.Area.Name = "Area";
            this.Area.Size = new System.Drawing.Size(41, 19);
            this.Area.TabIndex = 14;
            this.Area.Text = "Area";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Bashundhara R/A , Dhaka"});
            this.comboBox1.Location = new System.Drawing.Point(627, 468);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 26);
            this.comboBox1.TabIndex = 15;
            // 
            // Block
            // 
            this.Block.AutoSize = true;
            this.Block.BackColor = System.Drawing.Color.Gold;
            this.Block.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Block.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Block.Location = new System.Drawing.Point(483, 532);
            this.Block.Name = "Block";
            this.Block.Size = new System.Drawing.Size(50, 19);
            this.Block.TabIndex = 16;
            this.Block.Text = "Block";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "A",
            "B",
            "C",
            "D",
            "E",
            "F",
            "G",
            "H",
            "I",
            "J",
            "K"});
            this.comboBox2.Location = new System.Drawing.Point(627, 527);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 26);
            this.comboBox2.TabIndex = 17;
            // 
            // Road_No
            // 
            this.Road_No.AutoSize = true;
            this.Road_No.BackColor = System.Drawing.Color.Gold;
            this.Road_No.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Road_No.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Road_No.Location = new System.Drawing.Point(483, 587);
            this.Road_No.Name = "Road_No";
            this.Road_No.Size = new System.Drawing.Size(69, 19);
            this.Road_No.TabIndex = 18;
            this.Road_No.Text = "Road No";
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.textBox4.Location = new System.Drawing.Point(627, 582);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(119, 26);
            this.textBox4.TabIndex = 19;
            // 
            // Phone_Number
            // 
            this.Phone_Number.AutoSize = true;
            this.Phone_Number.BackColor = System.Drawing.Color.Gold;
            this.Phone_Number.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Phone_Number.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Phone_Number.Location = new System.Drawing.Point(483, 216);
            this.Phone_Number.Name = "Phone_Number";
            this.Phone_Number.Size = new System.Drawing.Size(111, 19);
            this.Phone_Number.TabIndex = 20;
            this.Phone_Number.Text = "Phone Number";
            this.Phone_Number.Click += new System.EventHandler(this.Phone_Number_Click);
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.textBox6.Location = new System.Drawing.Point(629, 211);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(119, 26);
            this.textBox6.TabIndex = 22;
            // 
            // Create_Account
            // 
            this.Create_Account.BackColor = System.Drawing.Color.Gold;
            this.Create_Account.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Create_Account.Location = new System.Drawing.Point(629, 663);
            this.Create_Account.Name = "Create_Account";
            this.Create_Account.Size = new System.Drawing.Size(133, 29);
            this.Create_Account.TabIndex = 23;
            this.Create_Account.Text = "Create Account";
            this.Create_Account.UseVisualStyleBackColor = false;
            this.Create_Account.Click += new System.EventHandler(this.Create_Account_Click);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(629, 369);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(60, 22);
            this.radioButton1.TabIndex = 24;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Male";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(717, 368);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(73, 22);
            this.radioButton2.TabIndex = 25;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Female";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // btlogin
            // 
            this.btlogin.BackColor = System.Drawing.Color.Gold;
            this.btlogin.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btlogin.Location = new System.Drawing.Point(801, 663);
            this.btlogin.Name = "btlogin";
            this.btlogin.Size = new System.Drawing.Size(133, 29);
            this.btlogin.TabIndex = 26;
            this.btlogin.Text = "Back To LogIn";
            this.btlogin.UseVisualStyleBackColor = false;
            this.btlogin.Click += new System.EventHandler(this.btlogin_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::WindowsFormsApp2.Properties.Resources.create_account;
            this.pictureBox1.Location = new System.Drawing.Point(0, -2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1385, 851);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // register
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1376, 861);
            this.Controls.Add(this.btlogin);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.Create_Account);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.Phone_Number);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.Road_No);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.Block);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.Area);
            this.Controls.Add(this.Gender);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.Age);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.Date_of_Birth);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.Password);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.UserName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "register";
            this.Text = "register";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label UserName;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label Password;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label Date_of_Birth;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label Age;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label Gender;
        private System.Windows.Forms.Label Area;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label Block;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label Road_No;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label Phone_Number;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Button Create_Account;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.Button btlogin;
    }
}