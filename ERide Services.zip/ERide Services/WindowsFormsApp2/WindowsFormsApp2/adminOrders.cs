﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class adminOrders : Form
    {
        private readonly string connectionString =
            @"Data Source=HPVICTUS15\SQLEXPRESS;Initial Catalog=ERideDB;Integrated Security=True";

        private readonly string phone_number;

        private int _selectedOrderId = -1;
        private string _currentStatus = "Pending";

        public adminOrders(string phone_number)
        {
            InitializeComponent();
            this.phone_number = phone_number;
        }

        public adminOrders()
        {
            InitializeComponent();
        }

        private void adminOrders_Load(object sender, EventArgs e)
        {
            SetupGridOrders();
            SetupGridOrderItems();

            SetStatus("Pending");   // default show pending
        }

        private void SetupGridOrders()
        {
            gridOrders.AutoGenerateColumns = false;
            gridOrders.ReadOnly = true;
            gridOrders.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            gridOrders.MultiSelect = false;
            gridOrders.AllowUserToAddRows = false;
            gridOrders.AllowUserToDeleteRows = false;
            gridOrders.Columns.Clear();

            DataGridViewTextBoxColumn colOrderId = new DataGridViewTextBoxColumn();
            colOrderId.Name = "colOrderId";
            colOrderId.HeaderText = "OrderId";
            colOrderId.DataPropertyName = "OrderId";
            colOrderId.Visible = false;
            gridOrders.Columns.Add(colOrderId);

            DataGridViewTextBoxColumn colUserPhone = new DataGridViewTextBoxColumn();
            colUserPhone.Name = "colUserPhone";
            colUserPhone.HeaderText = "User Phone";
            colUserPhone.DataPropertyName = "UserPhone";
            colUserPhone.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            gridOrders.Columns.Add(colUserPhone);

            DataGridViewTextBoxColumn colTotal = new DataGridViewTextBoxColumn();
            colTotal.Name = "colTotal";
            colTotal.HeaderText = "Total";
            colTotal.DataPropertyName = "TotalAmount";
            colTotal.Width = 120;
            gridOrders.Columns.Add(colTotal);

            DataGridViewTextBoxColumn colCreated = new DataGridViewTextBoxColumn();
            colCreated.Name = "colCreatedAt";
            colCreated.HeaderText = "Time";
            colCreated.DataPropertyName = "CreatedAt";
            colCreated.Width = 160;
            gridOrders.Columns.Add(colCreated);
        }

        private void SetupGridOrderItems()
        {
            gridOrderItems.AutoGenerateColumns = false;
            gridOrderItems.ReadOnly = true;
            gridOrderItems.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            gridOrderItems.MultiSelect = false;
            gridOrderItems.AllowUserToAddRows = false;
            gridOrderItems.AllowUserToDeleteRows = false;
            gridOrderItems.Columns.Clear();

            DataGridViewTextBoxColumn colFoodName = new DataGridViewTextBoxColumn();
            colFoodName.Name = "colFoodName";
            colFoodName.HeaderText = "Food";
            colFoodName.DataPropertyName = "FoodName";
            colFoodName.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            gridOrderItems.Columns.Add(colFoodName);

            DataGridViewTextBoxColumn colQty = new DataGridViewTextBoxColumn();
            colQty.Name = "colQty";
            colQty.HeaderText = "Qty";
            colQty.DataPropertyName = "Quantity";
            colQty.Width = 70;
            gridOrderItems.Columns.Add(colQty);

            DataGridViewTextBoxColumn colPrice = new DataGridViewTextBoxColumn();
            colPrice.Name = "colUnitPrice";
            colPrice.HeaderText = "Price";
            colPrice.DataPropertyName = "UnitPrice";
            colPrice.Width = 90;
            gridOrderItems.Columns.Add(colPrice);

            DataGridViewTextBoxColumn colLineTotal = new DataGridViewTextBoxColumn();
            colLineTotal.Name = "colLineTotal";
            colLineTotal.HeaderText = "LineTotal";
            colLineTotal.DataPropertyName = "LineTotal";
            colLineTotal.Width = 110;
            gridOrderItems.Columns.Add(colLineTotal);
        }

        private void SetStatus(string status)
        {
            _currentStatus = status;
            lblStatusInfo.Text = "Status: " + status;

            ClearSelectionUI();
            LoadOrders(status);
        }

        private void ClearSelectionUI()
        {
            _selectedOrderId = -1;
            lblSelectedOrderId.Text = "OrderId: -";
            lblSelectedUserPhone.Text = "User Phone: -";
            lblSelectedTotal.Text = "Total: 0.00";
            gridOrderItems.DataSource = null;
        }

        private void LoadOrders(string status)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = @"SELECT OrderId, UserPhone, TotalAmount, CreatedAt FROM dbo.Orders WHERE Status = @status ORDER BY CreatedAt DESC;";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@status", status);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                gridOrders.DataSource = dt;
            }
        }

        private void LoadOrderItems(int orderId)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = @"SELECT f.FoodName,oi.Quantity,oi.UnitPrice,(oi.Quantity * oi.UnitPrice) AS LineTotal FROM dbo.OrderItems oi INNER JOIN dbo.FoodItems f ON oi.FoodId = f.FoodId
                 WHERE oi.OrderId = @orderId;";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@orderId", orderId);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                gridOrderItems.DataSource = dt;
            }
        }

        private void gridOrders_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            if (gridOrders.Rows[e.RowIndex].Cells["colOrderId"].Value == null) return;

            _selectedOrderId = Convert.ToInt32(gridOrders.Rows[e.RowIndex].Cells["colOrderId"].Value);
            string userPhone = Convert.ToString(gridOrders.Rows[e.RowIndex].Cells["colUserPhone"].Value);
            decimal total = Convert.ToDecimal(gridOrders.Rows[e.RowIndex].Cells["colTotal"].Value);

            lblSelectedOrderId.Text = "OrderId: " + _selectedOrderId;
            lblSelectedUserPhone.Text = "User Phone: " + userPhone;
            lblSelectedTotal.Text = "Total: " + total.ToString("0.00");

            LoadOrderItems(_selectedOrderId);
        }

        private void UpdateOrderStatus(int orderId, string newStatus)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "UPDATE dbo.Orders SET Status=@status WHERE OrderId=@id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@status", newStatus);
                cmd.Parameters.AddWithValue("@id", orderId);

                con.Open();
                cmd.ExecuteNonQuery();
            }
        }

        private void btnPending_Click(object sender, EventArgs e)
        {
            SetStatus("Pending");
        }

        private void btnConfirmed_Click(object sender, EventArgs e)
        {
            SetStatus("Confirmed");
        }

        private void btnRejected_Click(object sender, EventArgs e)
        {
            SetStatus("Rejected");
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            SetStatus(_currentStatus);
        }

        private void btnAccept_Click(object sender, EventArgs e)
        {
            if (_selectedOrderId <= 0)
            {
                MessageBox.Show("Please select an order first.");
                return;
            }

            if (_currentStatus != "Pending")
            {
                MessageBox.Show("Only Pending orders can be Accepted.");
                return;
            }

            UpdateOrderStatus(_selectedOrderId, "Confirmed");
            MessageBox.Show("Order Confirmed.");

            SetStatus("Pending");
        }

        private void btnReject_Click(object sender, EventArgs e)
        {
            if (_selectedOrderId <= 0)
            {
                MessageBox.Show("Please select an order first.");
                return;
            }

            if (_currentStatus != "Pending")
            {
                MessageBox.Show("Only Pending orders can be Rejected.");
                return;
            }

            UpdateOrderStatus(_selectedOrderId, "Rejected");
            MessageBox.Show("Order Rejected.");

            SetStatus("Pending");
        }

        

        private void btnShowPending_Click(object sender, EventArgs e)
        {
            SetStatus("Pending");
        }

        private void btnShowConfirmed_Click(object sender, EventArgs e)
        {
            SetStatus("Confirmed");

        }

        private void btnShowRejected_Click(object sender, EventArgs e)
        {
            SetStatus("Rejected");

        }

        private void btnRefreshOrders_Click(object sender, EventArgs e)
        {
            SetStatus(_currentStatus);

        }

        private void btnReject_Click_1(object sender, EventArgs e)
        {
            if (_selectedOrderId <= 0)
            {
                MessageBox.Show("Please select an order first.");
                return;
            }

            if (_currentStatus != "Pending")
            {
                MessageBox.Show("Only Pending orders can be Rejected.");
                return;
            }

            UpdateOrderStatus(_selectedOrderId, "Rejected");
            MessageBox.Show("Order Rejected.");

            SetStatus("Pending");
        }

        private void btnAccept_Click_1(object sender, EventArgs e)
        {
            if (_selectedOrderId <= 0)
            {
                MessageBox.Show("Please select an order first.");
                return;
            }

            if (_currentStatus != "Pending")
            {
                MessageBox.Show("Only Pending orders can be Accepted.");
                return;
            }

            UpdateOrderStatus(_selectedOrderId, "Confirmed");
            MessageBox.Show("Order Confirmed.");

            SetStatus("Pending");
        }

        private void back_Click(object sender, EventArgs e)
        {
            adminfooddelivery adf = new adminfooddelivery(phone_number);
            adf.Show();
            this.Close();
        }
    }
}
