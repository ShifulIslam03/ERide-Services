﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class register : Form
    {
        public register()
        {
            InitializeComponent();
        }

        private void Phone_Number_Click(object sender, EventArgs e)
        {

        }

        private void Create_Account_Click(object sender, EventArgs e)
        {
            string connectionString = "data source=HPVICTUS15\\SQLEXPRESS; database=ERideDB; integrated security=SSPI";

            string username = textBox1.Text.Trim();
            string phone_number = textBox6.Text.Trim();
            string password = textBox2.Text.Trim();
            string age = textBox3.Text.Trim();
            string gender;
            if (radioButton1.Checked)
            {
                gender = radioButton1.Text;
            }
            else
            {
                gender = radioButton2.Text;
            }
            string date_of_birth = dateTimePicker1.Value.ToString("yyyy-MM-dd");
            string area = comboBox1.Text;
            string block = comboBox2.Text;
            string road_no = textBox4.Text.Trim();


            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(phone_number) ||
            string.IsNullOrWhiteSpace(password) || string.IsNullOrWhiteSpace(age) || string.IsNullOrWhiteSpace(gender) || string.IsNullOrWhiteSpace(date_of_birth) ||
            string.IsNullOrWhiteSpace(area) || string.IsNullOrWhiteSpace(block) || string.IsNullOrWhiteSpace(road_no))
            {
                MessageBox.Show("All fields must be filled out.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (!int.TryParse(age, out int parsedAge))
            {
                MessageBox.Show("Age must be a valid number.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            string query = "INSERT INTO Users (Username, Phone_Number, Password, Age, Gender, Date_of_Birth, Area, Block, Road) VALUES (@Username, @Phone_Number, @Password, @Age, @Gender, @Date_of_Birth, @Area, @Block, @Road)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@Phone_Number", phone_number);
                    command.Parameters.AddWithValue("@Password", password);
                    command.Parameters.AddWithValue("@Age", parsedAge);
                    command.Parameters.AddWithValue("@Gender", gender);
                    command.Parameters.AddWithValue("@Date_of_Birth", date_of_birth);
                    command.Parameters.AddWithValue("@Area", area);
                    command.Parameters.AddWithValue("@Block", block);
                    command.Parameters.AddWithValue("@Road", road_no);


                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Profile created successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Hide();
                        Form1 f1 = new Form1();
                        f1.Show();
                    }
                    else
                    {
                        MessageBox.Show("Failed to create the profile. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void Age_Click(object sender, EventArgs e)
        {

        }

        private void btlogin_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show(); 
            this.Close();
        }
    }
}
