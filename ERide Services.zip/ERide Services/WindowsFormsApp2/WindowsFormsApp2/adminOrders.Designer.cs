﻿namespace WindowsFormsApp2
{
    partial class adminOrders
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnShowPending = new System.Windows.Forms.Button();
            this.btnShowConfirmed = new System.Windows.Forms.Button();
            this.btnShowRejected = new System.Windows.Forms.Button();
            this.lblStatusInfo = new System.Windows.Forms.Label();
            this.gridOrders = new System.Windows.Forms.DataGridView();
            this.gridOrderItems = new System.Windows.Forms.DataGridView();
            this.lblSelectedOrderId = new System.Windows.Forms.Label();
            this.lblSelectedUserPhone = new System.Windows.Forms.Label();
            this.lblSelectedTotal = new System.Windows.Forms.Label();
            this.btnAccept = new System.Windows.Forms.Button();
            this.btnReject = new System.Windows.Forms.Button();
            this.btnRefreshOrders = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.back = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridOrders)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridOrderItems)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::WindowsFormsApp2.Properties.Resources.other_pages;
            this.pictureBox1.Location = new System.Drawing.Point(-1, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1378, 637);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Gold;
            this.pictureBox2.Location = new System.Drawing.Point(-1, 139);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(312, 101);
            this.pictureBox2.TabIndex = 5;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Gold;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(32, 177);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(236, 29);
            this.label1.TabIndex = 6;
            this.label1.Text = "Orders Management\r\n";
            // 
            // btnShowPending
            // 
            this.btnShowPending.BackColor = System.Drawing.Color.Gold;
            this.btnShowPending.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShowPending.Location = new System.Drawing.Point(539, 68);
            this.btnShowPending.Name = "btnShowPending";
            this.btnShowPending.Size = new System.Drawing.Size(113, 51);
            this.btnShowPending.TabIndex = 27;
            this.btnShowPending.Text = "Pending Orders";
            this.btnShowPending.UseVisualStyleBackColor = false;
            this.btnShowPending.Click += new System.EventHandler(this.btnShowPending_Click);
            // 
            // btnShowConfirmed
            // 
            this.btnShowConfirmed.BackColor = System.Drawing.Color.Gold;
            this.btnShowConfirmed.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShowConfirmed.Location = new System.Drawing.Point(688, 68);
            this.btnShowConfirmed.Name = "btnShowConfirmed";
            this.btnShowConfirmed.Size = new System.Drawing.Size(113, 51);
            this.btnShowConfirmed.TabIndex = 29;
            this.btnShowConfirmed.Text = "Confirmed Orders";
            this.btnShowConfirmed.UseVisualStyleBackColor = false;
            this.btnShowConfirmed.Click += new System.EventHandler(this.btnShowConfirmed_Click);
            // 
            // btnShowRejected
            // 
            this.btnShowRejected.BackColor = System.Drawing.Color.Gold;
            this.btnShowRejected.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShowRejected.Location = new System.Drawing.Point(839, 68);
            this.btnShowRejected.Name = "btnShowRejected";
            this.btnShowRejected.Size = new System.Drawing.Size(113, 51);
            this.btnShowRejected.TabIndex = 30;
            this.btnShowRejected.Text = "Rejected Orders";
            this.btnShowRejected.UseVisualStyleBackColor = false;
            this.btnShowRejected.Click += new System.EventHandler(this.btnShowRejected_Click);
            // 
            // lblStatusInfo
            // 
            this.lblStatusInfo.AutoSize = true;
            this.lblStatusInfo.BackColor = System.Drawing.Color.Gold;
            this.lblStatusInfo.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatusInfo.Location = new System.Drawing.Point(376, 139);
            this.lblStatusInfo.Name = "lblStatusInfo";
            this.lblStatusInfo.Size = new System.Drawing.Size(142, 23);
            this.lblStatusInfo.TabIndex = 31;
            this.lblStatusInfo.Text = "Status: Pending";
            // 
            // gridOrders
            // 
            this.gridOrders.AllowUserToAddRows = false;
            this.gridOrders.AllowUserToDeleteRows = false;
            this.gridOrders.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gridOrders.BackgroundColor = System.Drawing.Color.Gold;
            this.gridOrders.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridOrders.Location = new System.Drawing.Point(360, 177);
            this.gridOrders.MultiSelect = false;
            this.gridOrders.Name = "gridOrders";
            this.gridOrders.ReadOnly = true;
            this.gridOrders.RowHeadersVisible = false;
            this.gridOrders.RowHeadersWidth = 51;
            this.gridOrders.RowTemplate.Height = 24;
            this.gridOrders.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridOrders.Size = new System.Drawing.Size(441, 240);
            this.gridOrders.TabIndex = 32;
            this.gridOrders.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridOrders_CellClick);
            // 
            // gridOrderItems
            // 
            this.gridOrderItems.AllowUserToAddRows = false;
            this.gridOrderItems.AllowUserToDeleteRows = false;
            this.gridOrderItems.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gridOrderItems.BackgroundColor = System.Drawing.Color.Gold;
            this.gridOrderItems.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridOrderItems.Location = new System.Drawing.Point(839, 177);
            this.gridOrderItems.MultiSelect = false;
            this.gridOrderItems.Name = "gridOrderItems";
            this.gridOrderItems.ReadOnly = true;
            this.gridOrderItems.RowHeadersVisible = false;
            this.gridOrderItems.RowHeadersWidth = 51;
            this.gridOrderItems.RowTemplate.Height = 24;
            this.gridOrderItems.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridOrderItems.Size = new System.Drawing.Size(491, 240);
            this.gridOrderItems.TabIndex = 33;
            // 
            // lblSelectedOrderId
            // 
            this.lblSelectedOrderId.AutoSize = true;
            this.lblSelectedOrderId.BackColor = System.Drawing.Color.Gold;
            this.lblSelectedOrderId.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectedOrderId.Location = new System.Drawing.Point(835, 420);
            this.lblSelectedOrderId.Name = "lblSelectedOrderId";
            this.lblSelectedOrderId.Size = new System.Drawing.Size(98, 23);
            this.lblSelectedOrderId.TabIndex = 34;
            this.lblSelectedOrderId.Text = "OrderId: -";
            // 
            // lblSelectedUserPhone
            // 
            this.lblSelectedUserPhone.AutoSize = true;
            this.lblSelectedUserPhone.BackColor = System.Drawing.Color.Gold;
            this.lblSelectedUserPhone.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectedUserPhone.Location = new System.Drawing.Point(1040, 420);
            this.lblSelectedUserPhone.Name = "lblSelectedUserPhone";
            this.lblSelectedUserPhone.Size = new System.Drawing.Size(126, 23);
            this.lblSelectedUserPhone.TabIndex = 35;
            this.lblSelectedUserPhone.Text = "User Phone: -";
            // 
            // lblSelectedTotal
            // 
            this.lblSelectedTotal.AutoSize = true;
            this.lblSelectedTotal.BackColor = System.Drawing.Color.Gold;
            this.lblSelectedTotal.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectedTotal.Location = new System.Drawing.Point(1140, 472);
            this.lblSelectedTotal.Name = "lblSelectedTotal";
            this.lblSelectedTotal.Size = new System.Drawing.Size(100, 23);
            this.lblSelectedTotal.TabIndex = 36;
            this.lblSelectedTotal.Text = "Total: 0.00";
            // 
            // btnAccept
            // 
            this.btnAccept.BackColor = System.Drawing.Color.Gold;
            this.btnAccept.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAccept.Location = new System.Drawing.Point(566, 507);
            this.btnAccept.Name = "btnAccept";
            this.btnAccept.Size = new System.Drawing.Size(113, 51);
            this.btnAccept.TabIndex = 37;
            this.btnAccept.Text = "Accept";
            this.btnAccept.UseVisualStyleBackColor = false;
            this.btnAccept.Click += new System.EventHandler(this.btnAccept_Click_1);
            // 
            // btnReject
            // 
            this.btnReject.BackColor = System.Drawing.Color.Gold;
            this.btnReject.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReject.Location = new System.Drawing.Point(726, 508);
            this.btnReject.Name = "btnReject";
            this.btnReject.Size = new System.Drawing.Size(113, 51);
            this.btnReject.TabIndex = 38;
            this.btnReject.Text = "Reject";
            this.btnReject.UseVisualStyleBackColor = false;
            this.btnReject.Click += new System.EventHandler(this.btnReject_Click_1);
            // 
            // btnRefreshOrders
            // 
            this.btnRefreshOrders.BackColor = System.Drawing.Color.Gold;
            this.btnRefreshOrders.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefreshOrders.Location = new System.Drawing.Point(906, 508);
            this.btnRefreshOrders.Name = "btnRefreshOrders";
            this.btnRefreshOrders.Size = new System.Drawing.Size(113, 51);
            this.btnRefreshOrders.TabIndex = 39;
            this.btnRefreshOrders.Text = "Refresh";
            this.btnRefreshOrders.UseVisualStyleBackColor = false;
            this.btnRefreshOrders.Click += new System.EventHandler(this.btnRefreshOrders_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Gold;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(375, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(136, 26);
            this.label2.TabIndex = 40;
            this.label2.Text = "Show Orders";
            // 
            // back
            // 
            this.back.BackColor = System.Drawing.Color.Gold;
            this.back.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.back.Location = new System.Drawing.Point(1053, 508);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(113, 51);
            this.back.TabIndex = 41;
            this.back.Text = "Back";
            this.back.UseVisualStyleBackColor = false;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // adminOrders
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1378, 637);
            this.Controls.Add(this.back);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnRefreshOrders);
            this.Controls.Add(this.btnReject);
            this.Controls.Add(this.btnAccept);
            this.Controls.Add(this.lblSelectedTotal);
            this.Controls.Add(this.lblSelectedUserPhone);
            this.Controls.Add(this.lblSelectedOrderId);
            this.Controls.Add(this.gridOrderItems);
            this.Controls.Add(this.gridOrders);
            this.Controls.Add(this.lblStatusInfo);
            this.Controls.Add(this.btnShowRejected);
            this.Controls.Add(this.btnShowConfirmed);
            this.Controls.Add(this.btnShowPending);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "adminOrders";
            this.Text = "adminOrders";
            this.Load += new System.EventHandler(this.adminOrders_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridOrders)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridOrderItems)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnShowPending;
        private System.Windows.Forms.Button btnShowConfirmed;
        private System.Windows.Forms.Button btnShowRejected;
        private System.Windows.Forms.Label lblStatusInfo;
        private System.Windows.Forms.DataGridView gridOrders;
        private System.Windows.Forms.DataGridView gridOrderItems;
        private System.Windows.Forms.Label lblSelectedOrderId;
        private System.Windows.Forms.Label lblSelectedUserPhone;
        private System.Windows.Forms.Label lblSelectedTotal;
        private System.Windows.Forms.Button btnAccept;
        private System.Windows.Forms.Button btnReject;
        private System.Windows.Forms.Button btnRefreshOrders;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button back;
    }
}