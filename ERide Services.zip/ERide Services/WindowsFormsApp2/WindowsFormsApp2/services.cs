﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class services : Form
    {
            private string phone_number;   

            public services(string phone_number)
        {
            InitializeComponent();
            this.phone_number = phone_number;

        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {

        }

        private void rental_Click(object sender, EventArgs e)
        {

            rental r = new rental(phone_number);
            r.Show();
            this.Hide();
        }

        private void LogOut_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Close();
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            updateProfile up = new updateProfile(phone_number);
            up.Show();

            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            foodDelivery fd = new foodDelivery(phone_number);
            fd.Show();
            this.Hide();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }
    }
}
