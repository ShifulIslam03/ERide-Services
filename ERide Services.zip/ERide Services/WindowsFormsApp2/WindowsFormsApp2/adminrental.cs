﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class adminrental : Form
    {
        private readonly string connectionString =
            "data source=HPVICTUS15\\SQLEXPRESS; database=ERideDB; integrated security=SSPI";

        private readonly string phone_number;

        public adminrental(string phone_number)
        {
            InitializeComponent();
            this.phone_number = phone_number;
        }

        // designer safe
        public adminrental()
        {
            InitializeComponent();
            this.phone_number = null;
        }

        private void adminrental_Load(object sender, EventArgs e)
        {
            LoadStations();
        }

       
        private void LoadStations()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                using (SqlDataAdapter da = new SqlDataAdapter(
                    "SELECT StationId, Station_Name, Block, Road, Available FROM dbo.Station ORDER BY StationId", con))
                {
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = dt;

                    // Optional: auto column width
                    dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to load station data.\n" + ex.Message);
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            if (dataGridView1.Rows.Count == 0) return;

            DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

            txtStationName.Text = row.Cells["Station_Name"]?.Value?.ToString() ?? "";
            txtBlock.Text = row.Cells["Block"]?.Value?.ToString() ?? "";
            txtRoad.Text = row.Cells["Road"]?.Value?.ToString() ?? "";
            txtAvailable.Text = row.Cells["Available"]?.Value?.ToString() ?? "";
        }

        private void add_Click(object sender, EventArgs e)
        {
            string stationName = txtStationName.Text.Trim();
            string block = txtBlock.Text.Trim();

            if (string.IsNullOrWhiteSpace(stationName) || string.IsNullOrWhiteSpace(block))
            {
                MessageBox.Show("Please fill Station Name and Block.");
                return;
            }

            if (!int.TryParse(txtRoad.Text.Trim(), out int road))
            {
                MessageBox.Show("Road must be a number.");
                return;
            }

            if (!int.TryParse(txtAvailable.Text.Trim(), out int available))
            {
                MessageBox.Show("Available must be a number.");
                return;
            }

            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                using (SqlCommand cmd = new SqlCommand(
                    @"INSERT INTO dbo.Station (Station_Name, Block, Road, Available)
                      VALUES (@name, @block, @road, @available)", con))
                {
                    cmd.Parameters.Add("@name", SqlDbType.VarChar, 100).Value = stationName;
                    cmd.Parameters.Add("@block", SqlDbType.VarChar, 20).Value = block;
                    cmd.Parameters.Add("@road", SqlDbType.Int).Value = road;
                    cmd.Parameters.Add("@available", SqlDbType.Int).Value = available;

                    con.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Station added successfully.");
                ClearFields();
                LoadStations();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to add station.\n" + ex.Message);
            }
        }

        private void update_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Please select a station row first.");
                return;
            }

            if (dataGridView1.CurrentRow.Cells["StationId"]?.Value == null)
            {
                MessageBox.Show("Invalid selection.");
                return;
            }

            int stationId = Convert.ToInt32(dataGridView1.CurrentRow.Cells["StationId"].Value);

            string stationName = txtStationName.Text.Trim();
            string block = txtBlock.Text.Trim();

            if (string.IsNullOrWhiteSpace(stationName) || string.IsNullOrWhiteSpace(block))
            {
                MessageBox.Show("Please fill Station Name and Block.");
                return;
            }

            if (!int.TryParse(txtRoad.Text.Trim(), out int road))
            {
                MessageBox.Show("Road must be a number.");
                return;
            }

            if (!int.TryParse(txtAvailable.Text.Trim(), out int available))
            {
                MessageBox.Show("Available must be a number.");
                return;
            }

            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                using (SqlCommand cmd = new SqlCommand(
                    @"UPDATE dbo.Station
                      SET Station_Name=@name, Block=@block, Road=@road, Available=@available
                      WHERE StationId=@id", con))
                {
                    cmd.Parameters.Add("@name", SqlDbType.VarChar, 100).Value = stationName;
                    cmd.Parameters.Add("@block", SqlDbType.VarChar, 20).Value = block;
                    cmd.Parameters.Add("@road", SqlDbType.Int).Value = road;
                    cmd.Parameters.Add("@available", SqlDbType.Int).Value = available;
                    cmd.Parameters.Add("@id", SqlDbType.Int).Value = stationId;

                    con.Open();
                    int rows = cmd.ExecuteNonQuery();

                    if (rows == 0)
                    {
                        MessageBox.Show("Update failed. Station not found.");
                        return;
                    }
                }

                MessageBox.Show("Station updated successfully.");
                ClearFields();
                LoadStations();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to update station.\n" + ex.Message);
            }
        }

        private void exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ClearFields()
        {
            txtStationName.Clear();
            txtBlock.Clear();
            txtRoad.Clear();
            txtAvailable.Clear();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void delete_Click_1(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Please select a station row first.");
                return;
            }

            if (dataGridView1.CurrentRow.Cells["StationId"]?.Value == null)
            {
                MessageBox.Show("Invalid selection.");
                return;
            }

            int stationId = Convert.ToInt32(dataGridView1.CurrentRow.Cells["StationId"].Value);

            DialogResult confirm = MessageBox.Show(
                "Are you sure you want to delete this station?",
                "Confirm Delete",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            if (confirm != DialogResult.Yes) return;

            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                using (SqlCommand cmd = new SqlCommand(
                    "DELETE FROM dbo.Station WHERE StationId=@id", con))
                {
                    cmd.Parameters.Add("@id", SqlDbType.Int).Value = stationId;

                    con.Open();
                    int rows = cmd.ExecuteNonQuery();

                    if (rows == 0)
                    {
                        MessageBox.Show("Delete failed. Station not found.");
                        return;
                    }
                }

                MessageBox.Show("Station deleted successfully.");
                ClearFields();
                LoadStations();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Delete failed. This station may be referenced in another table.\n" + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to delete station.\n" + ex.Message);
            }
        }

        private void exit_Click_1(object sender, EventArgs e)
        {
            admindashboard ad = new admindashboard(phone_number);
            ad.Show();
            this.Close();
        }
    }
}
