﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class admindashboard : Form
    {
        private string phone_number;

        public admindashboard(string phone_number)
        {
            InitializeComponent();         
            this.phone_number = phone_number;
        }

        public admindashboard()
        {
            InitializeComponent();
        }

        private void admindashboard_Load(object sender, EventArgs e)
        {

        }

       

        private void pictureBox4_Click(object sender, EventArgs e)
        {   adminrental ar = new adminrental(phone_number); 
            ar.Show();
            this.Hide();
        }

        private void logout_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Close();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            adminfooddelivery adf = new adminfooddelivery(phone_number);
            adf.Show();
            this.Hide();
        }
    }

}
