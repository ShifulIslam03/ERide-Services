﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class updateProfile : Form
    {
        private readonly string connectionString =
            "data source=HPVICTUS15\\SQLEXPRESS; database=ERideDB; integrated security=SSPI";

        private string phone_number;

        public updateProfile(string phone_number)
        {
            InitializeComponent();
            this.phone_number = phone_number;

            LoadDetails();
        }

        
        public updateProfile()
        {
            InitializeComponent();
        }

        private void LoadDetails()
        {
            string query = @"SELECT Username, Phone_Number, [Password], Age, Gender, Date_of_Birth, Area, Block, Road FROM dbo.Users WHERE Phone_Number = @Phone_Number;";

            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@Phone_Number", phone_number);

                    con.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                           
                            textBox1.Text = reader["Username"]?.ToString();      
                            textBox2.Text = reader["Phone_Number"]?.ToString(); 
                            textBox3.Text = reader["Password"]?.ToString();     
                            textBox4.Text = reader["Age"]?.ToString();           
                            textBox5.Text = reader["Road"]?.ToString();         

                            
                            string gender = reader["Gender"]?.ToString();
                            radioButton1.Checked = (gender == "Male");
                            radioButton2.Checked = (gender == "Female");

                          
                            if (reader["Date_of_Birth"] != DBNull.Value)
                                dateTimePicker1.Value = Convert.ToDateTime(reader["Date_of_Birth"]).Date;

                           
                            comboBox1.Text = reader["Area"]?.ToString();
                            comboBox2.Text = reader["Block"]?.ToString();

                            
                            textBox2.ReadOnly = true;
                        }
                        else
                        {
                            MessageBox.Show("No user details found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to load user details.\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Close();
            }
        }

        private void update_Click(object sender, EventArgs e)
        {
            string newUsername = textBox1.Text.Trim();
            string newPassword = textBox3.Text.Trim();
            string newAgeText = textBox4.Text.Trim();

            string newGender = radioButton1.Checked
                ? "Male"
                : (radioButton2.Checked ? "Female" : "");

            DateTime newDateOfBirth = dateTimePicker1.Value.Date;

            string newArea = comboBox1.Text.Trim();
            string newBlock = comboBox2.Text.Trim();
            string newRoadText = textBox5.Text.Trim();

            
            if (string.IsNullOrWhiteSpace(newUsername) ||
                string.IsNullOrWhiteSpace(newPassword) ||
                string.IsNullOrWhiteSpace(newAgeText) ||
                string.IsNullOrWhiteSpace(newGender) ||
                string.IsNullOrWhiteSpace(newArea) ||
                string.IsNullOrWhiteSpace(newBlock) ||
                string.IsNullOrWhiteSpace(newRoadText))
            {
                MessageBox.Show("Please fill all fields.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(newAgeText, out int newAge) || newAge <= 0)
            {
                MessageBox.Show("Age must be a valid number.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(newRoadText, out int newRoad) || newRoad <= 0)
            {
                MessageBox.Show("Road must be a valid number.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string query = @" UPDATE dbo.Users SET Username = @Username, [Password] = @Password, Age = @Age, Gender = @Gender, Date_of_Birth = @DOB, Area = @Area, Block = @Block,Road = @Road WHERE Phone_Number = @Phone_Number;";

            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@Username", newUsername);
                    cmd.Parameters.AddWithValue("@Password", newPassword);
                    cmd.Parameters.AddWithValue("@Age", newAge);
                    cmd.Parameters.AddWithValue("@Gender", newGender);
                    cmd.Parameters.AddWithValue("@DOB", newDateOfBirth);
                    cmd.Parameters.AddWithValue("@Area", newArea);
                    cmd.Parameters.AddWithValue("@Block", newBlock);
                    cmd.Parameters.AddWithValue("@Road", newRoad);
                    cmd.Parameters.AddWithValue("@Phone_Number", phone_number);

                    con.Open();
                    int rows = cmd.ExecuteNonQuery();

                    if (rows > 0)
                        MessageBox.Show("Profile updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show("Update failed. User not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to update profile.\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void delete_Click(object sender, EventArgs e)
        {
            
        }

        private void exit_Click(object sender, EventArgs e)
        {
            
        }

        private void delete_Click_1(object sender, EventArgs e)
        {
            var confirm = MessageBox.Show(
                "Are you sure you want to delete your profile?",
                "Confirm Delete",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            if (confirm != DialogResult.Yes) return;

            string query = "DELETE FROM dbo.Users WHERE Phone_Number = @Phone_Number;";

            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@Phone_Number", phone_number);

                    con.Open();
                    int rows = cmd.ExecuteNonQuery();

                    if (rows > 0)
                    {
                        MessageBox.Show("Profile deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Delete failed. User not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Delete failed. This user may be referenced in another table.\n" + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to delete profile.\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void exit_Click_1(object sender, EventArgs e)
        {
            services f = new services(phone_number);
            f.Show();
            this.Close();
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            services f = new services(phone_number);
            f.Show();
            this.Close();
        }

        private void exit2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {

        }
    }
}
