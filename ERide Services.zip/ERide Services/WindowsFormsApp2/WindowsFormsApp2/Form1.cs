﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void UserName_Click(object sender, EventArgs e)
        {

        }

        private void Login_Click(object sender, EventArgs e)
        {
            string phone_number = textBox1.Text.Trim();
            string password = textBox2.Text;

            if (string.IsNullOrWhiteSpace(phone_number) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Please enter both Phone Number and Password.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string connectionString = "data source=HPVICTUS15\\SQLEXPRESS; database= ERideDB; integrated security=SSPI";

            string query = "SELECT COUNT(*) FROM Users WHERE Phone_Number = @Phone_Number AND Password COLLATE SQL_Latin1_General_CP1_CS_AS = @Password";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Phone_Number", phone_number);
                    command.Parameters.AddWithValue("@Password", password);

                    connection.Open();

                    int count = (int)command.ExecuteScalar();

                    if (count > 0)
                    {
                        MessageBox.Show("Login successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        
                        this.Hide();

                        services f3 = new services(phone_number);
                        f3.Show();

                    }
                    else
                    {
                        MessageBox.Show("Invalid Phone Number or Password.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void Register_Click(object sender, EventArgs e)
        {
            this.Hide();
            register r2 = new register();
            r2.Show();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void admin_Click(object sender, EventArgs e)
        {
            string phone_number = textBox1.Text.Trim();
            string password = textBox2.Text;

            if (string.IsNullOrWhiteSpace(phone_number) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Please enter both Phone Number and Password.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string connectionString = "data source=HPVICTUS15\\SQLEXPRESS; database= ERideDB; integrated security=SSPI";

            string query = "SELECT COUNT(*) FROM Admin WHERE Phone_Number = @Phone_Number AND Password COLLATE SQL_Latin1_General_CP1_CS_AS = @Password";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Phone_Number", phone_number);
                    command.Parameters.AddWithValue("@Password", password);

                    connection.Open();

                    int count = (int)command.ExecuteScalar();

                    if (count > 0)
                    {
                        MessageBox.Show("Login successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        this.Hide();

                        admindashboard ad = new admindashboard(phone_number);
                        ad.Show();

                    }
                    else
                    {
                        MessageBox.Show("Invalid Phone Number or Password.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
    }
}
