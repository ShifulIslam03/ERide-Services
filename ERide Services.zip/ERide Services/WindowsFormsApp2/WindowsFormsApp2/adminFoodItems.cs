﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class adminFoodItems : Form
    {
        private readonly string connectionString =
            @"Data Source=HPVICTUS15\SQLEXPRESS;Initial Catalog=ERideDB;Integrated Security=True";

        private readonly string phone_number;

        private DataTable foodTable;

        // ✅ IMPORTANT: user select করা restaurant id এখানে রাখবো
        private int? _currentRestaurantId = null;

        // ✅ binding time এ event fire হলে ignore
        private bool _suppressRestaurantEvents = false;

        public adminFoodItems(string phone_number)
        {
            InitializeComponent();
            this.phone_number = phone_number;

            WireEvents(); // ✅ run-time এ unwanted events detach/attach
        }

        public adminFoodItems()
        {
            InitializeComponent();
            WireEvents();
        }

        private void WireEvents()
        {
            // ✅ combo: only SelectionChangeCommitted allowed
            cmbRestaurant.SelectionChangeCommitted -= cmbRestaurant_SelectionChangeCommitted;
            cmbRestaurant.SelectionChangeCommitted += cmbRestaurant_SelectionChangeCommitted;

            // (যদি Designer এ accidentally attach থাকে, run-time এ খুলে দিচ্ছি)
            cmbRestaurant.SelectedIndexChanged -= cmbRestaurant_SelectedIndexChanged;
            cmbRestaurant.SelectedValueChanged -= cmbRestaurant_SelectedValueChanged;
            cmbRestaurant.Click -= cmbRestaurant_Click;

            // ✅ grid: use CellClick only
            gridFoodItems.CellClick -= gridFoodItems_CellClick;
            gridFoodItems.CellClick += gridFoodItems_CellClick;

            gridFoodItems.CellContentClick -= gridFoodItems_CellContentClick;
        }

        // dummy handlers (যাতে remove করা যায়)
        private void cmbRestaurant_SelectedIndexChanged(object sender, EventArgs e) { }
        private void cmbRestaurant_SelectedValueChanged(object sender, EventArgs e) { }
        private void cmbRestaurant_Click(object sender, EventArgs e) { }
        private void gridFoodItems_CellContentClick(object sender, DataGridViewCellEventArgs e) { }

        // ================= FORM LOAD =================
        private void adminFoodItems_Load(object sender, EventArgs e)
        {
            cmbRestaurant.DropDownStyle = ComboBoxStyle.DropDownList;

            gridFoodItems.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            gridFoodItems.MultiSelect = false;
            gridFoodItems.ReadOnly = true;
            gridFoodItems.AutoGenerateColumns = false;

            SetupGridFoodItems();
            LoadRestaurants();

            gridFoodItems.DataSource = null;
            ClearInputs();
        }

        private void SetupGridFoodItems()
        {
            gridFoodItems.Columns.Clear();

            gridFoodItems.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "colFoodId",
                HeaderText = "FoodId",
                DataPropertyName = "FoodId",
                Visible = false
            });

            gridFoodItems.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "colRestaurantId",
                HeaderText = "RestaurantId",
                DataPropertyName = "RestaurantId",
                Visible = false
            });

            gridFoodItems.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "colFoodName",
                HeaderText = "Food Name",
                DataPropertyName = "FoodName",
                AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill
            });

            gridFoodItems.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "colPrice",
                HeaderText = "Price",
                DataPropertyName = "Price",
                Width = 90
            });

            gridFoodItems.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "colFoodQuantity",
                HeaderText = "Quantity",
                DataPropertyName = "FoodQuantity",
                Width = 90
            });

            gridFoodItems.Columns.Add(new DataGridViewCheckBoxColumn
            {
                Name = "colIsAvailable",
                HeaderText = "Available",
                DataPropertyName = "IsAvailable",
                Width = 80
            });
        }

        private void LoadRestaurants()
        {
            _suppressRestaurantEvents = true;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT RestaurantId, RestaurantName FROM dbo.Restaurants ORDER BY RestaurantName";
                SqlDataAdapter da = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);

                cmbRestaurant.DataSource = dt;
                cmbRestaurant.DisplayMember = "RestaurantName";
                cmbRestaurant.ValueMember = "RestaurantId";
                cmbRestaurant.SelectedIndex = -1;
            }

            _currentRestaurantId = null; 
            _suppressRestaurantEvents = false;
        }

        
        private void cmbRestaurant_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (_suppressRestaurantEvents) return;

            if (cmbRestaurant.SelectedValue == null) return;

            if (int.TryParse(cmbRestaurant.SelectedValue.ToString(), out int rid))
            {
                _currentRestaurantId = rid; 
                LoadFoodItems(rid);
                ClearInputs();
            }
        }

        
        private void LoadFoodItems(int restaurantId)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = @"
SELECT FoodId, RestaurantId, FoodName, Price, FoodQuantity, IsAvailable
FROM dbo.FoodItems
WHERE RestaurantId = @rid
ORDER BY FoodName";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.Add("@rid", SqlDbType.Int).Value = restaurantId;

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                foodTable = new DataTable();
                da.Fill(foodTable);

                gridFoodItems.DataSource = foodTable;
            }
        }

        // ================= GRID CLICK (DO NOT TOUCH COMBO!) =================
        private void gridFoodItems_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            if (gridFoodItems.Rows[e.RowIndex] == null) return;

            var row = gridFoodItems.Rows[e.RowIndex];

            txtFoodName.Text = Convert.ToString(row.Cells["colFoodName"].Value);
            txtPrice.Text = Convert.ToString(row.Cells["colPrice"].Value);
            txtQty.Text = Convert.ToString(row.Cells["colFoodQuantity"].Value);

            object availVal = row.Cells["colIsAvailable"].Value;
            chkIsAvailable.Checked = (availVal != null && availVal != DBNull.Value) && Convert.ToBoolean(availVal);
        }

        // ================= VALIDATION =================
        private bool ValidateInputs(out decimal price, out int qty)
        {
            price = 0;
            qty = 0;

            if (_currentRestaurantId == null)
            {
                MessageBox.Show("Please select a restaurant first.");
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtFoodName.Text))
            {
                MessageBox.Show("Please enter Food Name.");
                return false;
            }

            if (!decimal.TryParse(txtPrice.Text.Trim(), out price) || price < 0)
            {
                MessageBox.Show("Price must be a valid number.");
                return false;
            }

            if (!int.TryParse(txtQty.Text.Trim(), out qty) || qty < 0)
            {
                MessageBox.Show("Quantity must be a valid integer.");
                return false;
            }

            return true;
        }

        // ================= ADD =================
        private void btnAddFood_Click(object sender, EventArgs e)
        {
            if (!ValidateInputs(out decimal price, out int qty)) return;

            int rid = _currentRestaurantId.Value;
            bool isAvail = chkIsAvailable.Checked;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = @"
INSERT INTO dbo.FoodItems (RestaurantId, FoodName, Price, FoodQuantity, IsAvailable)
VALUES (@rid, @name, @price, @qty, @avail)";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.Add("@rid", SqlDbType.Int).Value = rid;
                cmd.Parameters.Add("@name", SqlDbType.NVarChar, 200).Value = txtFoodName.Text.Trim();
                cmd.Parameters.Add("@price", SqlDbType.Decimal).Value = price;
                cmd.Parameters.Add("@qty", SqlDbType.Int).Value = qty;
                cmd.Parameters.Add("@avail", SqlDbType.Bit).Value = isAvail;

                con.Open();
                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Food item added.");
            LoadFoodItems(rid);
            ClearInputs();
        }

        // ================= UPDATE =================
        private void btnUpdateFood_Click(object sender, EventArgs e)
        {
            if (gridFoodItems.CurrentRow == null)
            {
                MessageBox.Show("Please select a food item from the grid.");
                return;
            }

            if (!ValidateInputs(out decimal price, out int qty)) return;

            int rid = _currentRestaurantId.Value;
            int foodId = Convert.ToInt32(gridFoodItems.CurrentRow.Cells["colFoodId"].Value);
            bool isAvail = chkIsAvailable.Checked;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = @"
UPDATE dbo.FoodItems
SET FoodName = @name,
    Price = @price,
    FoodQuantity = @qty,
    IsAvailable = @avail
WHERE FoodId = @foodId AND RestaurantId = @rid";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.Add("@name", SqlDbType.NVarChar, 200).Value = txtFoodName.Text.Trim();
                cmd.Parameters.Add("@price", SqlDbType.Decimal).Value = price;
                cmd.Parameters.Add("@qty", SqlDbType.Int).Value = qty;
                cmd.Parameters.Add("@avail", SqlDbType.Bit).Value = isAvail;
                cmd.Parameters.Add("@foodId", SqlDbType.Int).Value = foodId;
                cmd.Parameters.Add("@rid", SqlDbType.Int).Value = rid;

                con.Open();
                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Food item updated.");
            LoadFoodItems(rid);
            ClearInputs();
        }

        // ================= DELETE =================
        private void btnDeleteFood_Click(object sender, EventArgs e)
        {
            if (gridFoodItems.CurrentRow == null)
            {
                MessageBox.Show("Please select a food item from the grid.");
                return;
            }

            if (_currentRestaurantId == null)
            {
                MessageBox.Show("Please select a restaurant first.");
                return;
            }

            DialogResult dr = MessageBox.Show("Are you sure to delete this food item?",
                "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (dr != DialogResult.Yes) return;

            int rid = _currentRestaurantId.Value;
            int foodId = Convert.ToInt32(gridFoodItems.CurrentRow.Cells["colFoodId"].Value);

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM dbo.FoodItems WHERE FoodId = @foodId AND RestaurantId = @rid";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.Add("@foodId", SqlDbType.Int).Value = foodId;
                cmd.Parameters.Add("@rid", SqlDbType.Int).Value = rid;

                con.Open();
                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Food item deleted.");
            LoadFoodItems(rid);
            ClearInputs();
        }

        // ================= CLEAR =================
        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearInputs();
        }

        private void ClearInputs()
        {
            txtFoodName.Clear();
            txtPrice.Clear();
            txtQty.Clear();
            chkIsAvailable.Checked = false;
        }

        // ================= REFRESH =================
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadRestaurants();
            gridFoodItems.DataSource = null;
            ClearInputs();
        }

        // ================= BACK =================
        private void btnBack_Click(object sender, EventArgs e)
        {
            adminfooddelivery adf = new adminfooddelivery(phone_number);
            adf.Show();
            this.Close();
        }
    }
}
