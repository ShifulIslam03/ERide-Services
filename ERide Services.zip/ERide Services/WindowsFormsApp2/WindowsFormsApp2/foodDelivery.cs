﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class foodDelivery : Form

    {
        private string phone_number;

        public foodDelivery(string phone_number)
        {
            InitializeComponent();
            this.phone_number = phone_number;
        }

        private string connectionString =
            @"Data Source=HPVICTUS15\SQLEXPRESS;Initial Catalog=ERideDB;Integrated Security=True";
        public foodDelivery()
        {
            InitializeComponent();
        }
        private DataTable cartTable;

        private void SetupCartTable()
        {
            cartTable = new DataTable();
            cartTable.Columns.Add("FoodId", typeof(int));
            cartTable.Columns.Add("FoodName", typeof(string));
            cartTable.Columns.Add("Price", typeof(decimal));
            cartTable.Columns.Add("Qty", typeof(int));
            cartTable.Columns.Add("LineTotal", typeof(decimal));

            gridCart.AutoGenerateColumns = true;
            gridCart.DataSource = cartTable;
        }


        private void btnLoadMenu_Click(object sender, EventArgs e)
        {
            gridMenu.AutoGenerateColumns = false;

            if (cmbRestaurant.SelectedValue == null)
            {
                MessageBox.Show("Please select a restaurant");
                return;
            }

            gridMenu.AutoGenerateColumns = false;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = @"
        SELECT FoodId, FoodName, Price, FoodQuantity, IsAvailable
        FROM FoodItems
        WHERE RestaurantId = @rid AND IsAvailable = 1";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@rid", cmbRestaurant.SelectedValue);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                gridMenu.DataSource = dt;
            }
        }


        

        private void gridMenu_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void foodDelivery_Load(object sender, EventArgs e)
        {
            SetupGridMenuColumns();
            LoadRestaurants();
            SetupCartTable();
        }

        private void LoadRestaurants()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT RestaurantId, RestaurantName FROM Restaurants ORDER BY RestaurantName";
                SqlDataAdapter da = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);

                cmbRestaurant.DataSource = dt;
                cmbRestaurant.DisplayMember = "RestaurantName"; 
                cmbRestaurant.ValueMember = "RestaurantId";     
                cmbRestaurant.SelectedIndex = -1;               
            }
        }

        private void SetupGridMenuColumns()
        {
            gridMenu.AutoGenerateColumns = false;
            gridMenu.Columns.Clear();

          
            DataGridViewTextBoxColumn colFoodId = new DataGridViewTextBoxColumn();
            colFoodId.Name = "colFoodId";
            colFoodId.HeaderText = "FoodId";
            colFoodId.DataPropertyName = "FoodId";
            colFoodId.Visible = false;
            gridMenu.Columns.Add(colFoodId);

            
            DataGridViewTextBoxColumn colFoodName = new DataGridViewTextBoxColumn();
            colFoodName.Name = "colFoodName";
            colFoodName.HeaderText = "Food Name";
            colFoodName.DataPropertyName = "FoodName";
            gridMenu.Columns.Add(colFoodName);

        
            DataGridViewTextBoxColumn colPrice = new DataGridViewTextBoxColumn();
            colPrice.Name = "colPrice";
            colPrice.HeaderText = "Price";
            colPrice.DataPropertyName = "Price";
            gridMenu.Columns.Add(colPrice);

         
            DataGridViewTextBoxColumn colQty = new DataGridViewTextBoxColumn();
            colQty.Name = "colFoodQuantity";
            colQty.HeaderText = "Available Qty";
            colQty.DataPropertyName = "FoodQuantity";
            gridMenu.Columns.Add(colQty);

            
            DataGridViewTextBoxColumn colAvail = new DataGridViewTextBoxColumn();
            colAvail.Name = "colIsAvailable";
            colAvail.HeaderText = "Available";
            colAvail.DataPropertyName = "IsAvailable";
            gridMenu.Columns.Add(colAvail);

            
        }
        private void UpdateTotal()
        {
            decimal total = 0;
            foreach (DataRow row in cartTable.Rows)
                total += Convert.ToDecimal(row["LineTotal"]);

            lbltotal.Text = "Total: " + total.ToString("0.00");
        }

        private void btnAddToCart_Click(object sender, EventArgs e)
        {
            if (gridMenu.CurrentRow == null)
            {
                MessageBox.Show("Please select a food item from menu.");
                return;
            }

            int foodId = Convert.ToInt32(gridMenu.CurrentRow.Cells["colFoodId"].Value);
            string foodName = gridMenu.CurrentRow.Cells["colFoodName"].Value.ToString();
            decimal price = Convert.ToDecimal(gridMenu.CurrentRow.Cells["colPrice"].Value);
            int availableQty = Convert.ToInt32(gridMenu.CurrentRow.Cells["colFoodQuantity"].Value);

            int qty = (int)numQty.Value;

            if (qty > availableQty)
            {
                MessageBox.Show("Not enough stock available.");
                return;
            }

            
            DataRow existing = cartTable.AsEnumerable()
                .FirstOrDefault(r => (int)r["FoodId"] == foodId);

            if (existing != null)
            {
                int newQty = (int)existing["Qty"] + qty;
                if (newQty > availableQty)
                {
                    MessageBox.Show("Cart quantity exceeds available stock.");
                    return;
                }

                existing["Qty"] = newQty;
                existing["LineTotal"] = newQty * price;
            }
            else
            {
                cartTable.Rows.Add(foodId, foodName, price, qty, qty * price);
            }

            UpdateTotal();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (gridCart.CurrentRow == null)
            {
                MessageBox.Show("Please select an item from cart.");
                return;
            }

            if (gridCart.CurrentRow.Cells["FoodId"].Value == null)
            {
                MessageBox.Show("Invalid cart row.");
                return;
            }

            int foodId = Convert.ToInt32(gridCart.CurrentRow.Cells["FoodId"].Value);

            DataRow row = cartTable.AsEnumerable()
                .FirstOrDefault(r => Convert.ToInt32(r["FoodId"]) == foodId);

            if (row != null)
            {
                row.Delete();
                cartTable.AcceptChanges();
                UpdateTotal();
            }
        }

        private void btnPlaceOrder_Click(object sender, EventArgs e)
        {if (cartTable == null || cartTable.Rows.Count == 0)
            {
                MessageBox.Show("Your cart is empty.");
                return;
            }

            if (cmbRestaurant.SelectedValue == null)
            {
                MessageBox.Show("Please select a restaurant.");
                return;
            }

            int restaurantId = Convert.ToInt32(cmbRestaurant.SelectedValue);

            decimal total = 0;
            foreach (DataRow r in cartTable.Rows)
                total += Convert.ToDecimal(r["LineTotal"]);

            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    SqlTransaction tran = con.BeginTransaction();

                    try
                    {
                      
                        int orderId;
                        using (SqlCommand cmd = new SqlCommand(@" INSERT INTO dbo.Orders (UserPhone, RestaurantId, TotalAmount, Status, CreatedAt) VALUES (@phone, @rid, @total, @status, GETDATE()); SELECT SCOPE_IDENTITY(); ", con, tran))
                        {
                            cmd.Parameters.AddWithValue("@phone", phone_number);
                            cmd.Parameters.AddWithValue("@rid", restaurantId);
                            cmd.Parameters.AddWithValue("@total", total);
                            cmd.Parameters.AddWithValue("@status", "Pending");

                            orderId = Convert.ToInt32(cmd.ExecuteScalar());
                        }

                       
                        foreach (DataRow r in cartTable.Rows)
                        {
                            int foodId = Convert.ToInt32(r["FoodId"]);
                            decimal price = Convert.ToDecimal(r["Price"]);
                            int qty = Convert.ToInt32(r["Qty"]);

                            
                            using (SqlCommand stockCmd = new SqlCommand(@" UPDATE dbo.FoodItems SET FoodQuantity = FoodQuantity - @qty, IsAvailable = CASE WHEN (FoodQuantity - @qty) > 0 THEN 1 ELSE 0 END WHERE FoodId = @foodId AND FoodQuantity >= @qty;", con, tran))
                            {
                                stockCmd.Parameters.AddWithValue("@qty", qty);
                                stockCmd.Parameters.AddWithValue("@foodId", foodId);

                                int affected = stockCmd.ExecuteNonQuery();
                                if (affected == 0)
                                {
                                    throw new Exception("Not enough stock for FoodId: " + foodId);
                                }
                            }

                            // Insert OrderItems
                            using (SqlCommand itemCmd = new SqlCommand(@" INSERT INTO dbo.OrderItems (OrderId, FoodId, Quantity, UnitPrice) VALUES (@orderId, @foodId, @qty, @price); ", con, tran))
                            {
                                itemCmd.Parameters.AddWithValue("@orderId", orderId);
                                itemCmd.Parameters.AddWithValue("@foodId", foodId);
                                itemCmd.Parameters.AddWithValue("@qty", qty);
                                itemCmd.Parameters.AddWithValue("@price", price);
                                itemCmd.ExecuteNonQuery();
                            }
                        }

                        tran.Commit();

                        MessageBox.Show("Order placed successfully.");

                        cartTable.Clear();
                        UpdateTotal();

                        btnLoadMenu_Click(null, null);
                    }
                    catch
                    {
                        tran.Rollback();
                        throw;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to place order.\n" + ex.Message);
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            services f = new services(phone_number);
            f.Show();
            this.Close();
        }
    }
}



