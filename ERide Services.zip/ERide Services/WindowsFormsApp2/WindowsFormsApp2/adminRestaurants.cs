﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class adminRestaurants : Form
    {
        private string connectionString =
            @"Data Source=HPVICTUS15\SQLEXPRESS;Initial Catalog=ERideDB;Integrated Security=True";

        private readonly string phone_number;

        // ================= CONSTRUCTORS =================
        public adminRestaurants(string phone_number)
        {
            InitializeComponent();
            this.phone_number = phone_number;
        }

        public adminRestaurants()
        {
            InitializeComponent();
        }

        // ================= FORM LOAD =================
        private void adminRestaurants_Load(object sender, EventArgs e)
        {
            SetupGridRestaurants();
            LoadRestaurants();
        }

        // ================= GRID SETUP =================
        private void SetupGridRestaurants()
        {
            gridRestaurants.AutoGenerateColumns = false;
            gridRestaurants.Columns.Clear();

            // Hidden RestaurantId
            DataGridViewTextBoxColumn colId = new DataGridViewTextBoxColumn();
            colId.Name = "RestaurantId";              // ✅ IMPORTANT
            colId.HeaderText = "Id";
            colId.DataPropertyName = "RestaurantId";
            colId.Visible = false;
            gridRestaurants.Columns.Add(colId);

            // Restaurant Name
            DataGridViewTextBoxColumn colName = new DataGridViewTextBoxColumn();
            colName.Name = "RestaurantName";
            colName.HeaderText = "Restaurant Name";
            colName.DataPropertyName = "RestaurantName";
            colName.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            gridRestaurants.Columns.Add(colName);
        }

        // ================= LOAD RESTAURANTS =================
        private void LoadRestaurants()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT RestaurantId, RestaurantName FROM Restaurants ORDER BY RestaurantName";
                SqlDataAdapter da = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);

                gridRestaurants.DataSource = dt;
            }
        }

        // ================= GRID CLICK => TEXTBOX =================
        private void gridRestaurants_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (gridRestaurants.CurrentRow == null) return;

            object nameVal = gridRestaurants.CurrentRow.Cells["RestaurantName"].Value;
            txtRestaurantName.Text = nameVal == null ? "" : nameVal.ToString();
        }

        // ================= ADD =================
        private void btnAddRestaurant_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtRestaurantName.Text))
            {
                MessageBox.Show("Please enter restaurant name");
                return;
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Restaurants (RestaurantName) VALUES (@name)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@name", txtRestaurantName.Text.Trim());

                con.Open();
                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Restaurant added successfully");
            txtRestaurantName.Clear();
            LoadRestaurants();
        }

        // ================= UPDATE =================
        private void btnUpdateRestaurant_Click(object sender, EventArgs e)
        {
            if (gridRestaurants.CurrentRow == null ||
                gridRestaurants.CurrentRow.Cells["RestaurantId"].Value == null)
            {
                MessageBox.Show("Please select a restaurant");
                return;
            }

            if (string.IsNullOrWhiteSpace(txtRestaurantName.Text))
            {
                MessageBox.Show("Please enter restaurant name");
                return;
            }

            int id = Convert.ToInt32(gridRestaurants.CurrentRow.Cells["RestaurantId"].Value);

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "UPDATE Restaurants SET RestaurantName=@name WHERE RestaurantId=@id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@name", txtRestaurantName.Text.Trim());
                cmd.Parameters.AddWithValue("@id", id);

                con.Open();
                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Restaurant updated successfully");
            txtRestaurantName.Clear();
            LoadRestaurants();
        }

        // ================= DELETE =================
        private void btnDeleteRestaurant_Click(object sender, EventArgs e)
        {
            if (gridRestaurants.CurrentRow == null ||
                gridRestaurants.CurrentRow.Cells["RestaurantId"].Value == null)
            {
                MessageBox.Show("Please select a restaurant");
                return;
            }

            DialogResult dr = MessageBox.Show(
                "Are you sure to delete this restaurant?",
                "Confirm",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            if (dr != DialogResult.Yes) return;

            int id = Convert.ToInt32(gridRestaurants.CurrentRow.Cells["RestaurantId"].Value);

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM Restaurants WHERE RestaurantId=@id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@id", id);

                con.Open();
                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Restaurant deleted successfully");
            txtRestaurantName.Clear();
            LoadRestaurants();
        }

        // ================= REFRESH =================
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            txtRestaurantName.Clear();
            LoadRestaurants();
        }

        // =========================================================
        // ✅ THESE TWO METHODS ARE ONLY FOR DESIGNER ERROR FIX
        // =========================================================

        // Designer might be wired to this event, so keep it
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            // do nothing
        }

        // Designer might be wired to this event, so keep it
        private void gridRestaurants_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // do nothing
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            adminfooddelivery adf = new adminfooddelivery(phone_number);
            adf.Show();
            this.Close();
        }
    }
}
